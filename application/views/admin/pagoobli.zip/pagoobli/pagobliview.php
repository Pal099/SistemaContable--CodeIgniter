<p><strong>Número:</strong> <?php echo $obligaciones->numero; ?></p>
<p><strong>Contabilidad:</strong> <?php echo $obligaciones->contabilidad; ?></p>
<p><strong>Dirección:</strong> <?php echo $obligaciones->direccion; ?></p>
<p><strong>Teléfono:</strong> <?php echo $obligaciones->telefono; ?></p>
<p><strong>Ruc:</strong> <?php echo $obligaciones->ruc; ?></p>
<p><strong>Observación:</strong> <?php echo $obligaciones->observacion; ?></p>
<p><strong>Fecha:</strong> <?php echo $obligaciones->fecha; ?></p>
<p><strong>Tesoreria:</strong> <?php echo $obligaciones->tesoreria; ?></p>
<p><strong>Pedi. Matricula:</strong> <?php echo $obligaciones->pedi_matricula; ?></p>
<p><strong>Modalidad:</strong> <?php echo $obligaciones->modalidad; ?></p>
<p><strong>Tipo de presupuesto:</strong> <?php echo $obligaciones->tipo_presupuesto; ?></p>
<p><strong>Unidad responsable:</strong> <?php echo $obligaciones->unidad_respon; ?></p>
<p><strong>Proyecto:</strong> <?php echo $obligaciones->contabilidad; ?></p>
<p><strong>Estado:</strong> <?php echo $obligaciones->contabilidad; ?></p>
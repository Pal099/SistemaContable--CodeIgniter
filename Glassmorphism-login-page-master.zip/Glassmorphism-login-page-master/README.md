<h1 align='center' style="font-size:5rem"><b>Risponsive Glassmorphism Login Page</b></h1>

</div>
<br><br><br>
<h2 align='center'>
    You can use this login page for your project ,furthermore customize it to working in real websites.
</h2>

<br><br><br>

<div align='center'>
    <h2>Desktop Mode</h2>
    <img style='border-radius:5px' src="./images/desktop.png"></img>
</div>
<hr/>
<div align='center'>
    <h2>Mobile Mode</h2>
    <img style='border-radius:5px' src="./images/mobile.png"></img>
</div>
<hr>

<br><br><br><br>

<h1 align='center'><b>Abilities</b></h1>

<ul>
    <li> This is just an UI nothing more, don't expect anything more than just beauty :)</li>
</ul>

<hr>
<br><br><br><br>
<h1 align='center'><b>Language and technologies used in This Project</h1>
<img src="https://img.shields.io/badge/WebStorm-000000?style=for-the-badge&logo=WebStorm&logoColor=white"/>
<img src="https://img.shields.io/badge/VSCode-0078D4?style=for-the-badge&logo=visual%20studio%20code&logoColor=white"/>
<img src="https://img.shields.io/badge/NPM-%23000000.svg?style=for-the-badge&logo=npm&logoColor=white"/>
<img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white"/>
<img src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white"/>
<img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E"/>
<img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=typescript&logoColor=%23F7DF1E"/>
<img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB"/>
<img src="https://img.shields.io/badge/Material%20UI-007FFF?style=for-the-badge&logo=mui&logoColor=white"/>
<img src="https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white"/>

<br><br><br><br>

<h1 align='center'><b>Requirements</b></h1>

Download and install `NodeJS` from official website <a href="https://nodejs.org/">nodeJS.org</a>

<br><br><br><br>

<h1 align='center'><b>How To Run</b></h1>

At first you have to clone the project and open it in `IDE`

<br>

Open IDE's terminal and then write `~ npm i` to install dependencies

<br>

Then write `~ npm start` and then enter

Congratulations ,now you can use this page for your beautiful project.
